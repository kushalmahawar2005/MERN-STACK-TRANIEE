// let a = 1;
// let b = ++a;
// a++;
// console.log("value of a is :", a);
// console.log("value of b is :", b);


// console.log(NaN === NaN); 

// let a  = null;
// console.log(++a);
// console.log(a++);

// let a = false;
// let b = true;

// console.log(a || b);

// let num = 81;
// if (num % 2 === 0){
//     console.log("Given number is even number ");
// } else  {
//     console.log("Given no is odd number");
// }

// let age = 5;
// if (age >= 18) {
//     console.log("You are eleigible to vote");
// }
// else {
//     console.log("You are not eligible to vote");
// }



// const marks = 85;
// let Branch;

// switch (true)
//  {
//     case marks >= 90:
//     Branch = "Computer Science";
//     break;

//     case marks >= 80:
//         Branch = "Information Technology";
//         break;

//     case marks >= 70:
//             Branch = "Electrical";
//             break; 

//     default:
//     Branch = "Padoge likhoge to banoge Nawab";
//     break; 
//  }
// console.log("Branch is :", Branch);


// for (let i = 1; i <= 5; i++) {
//     console.log("Hello World", i);
// }
// console.log("Loop ended");

// let sum = 0; 
// for (let i = 1;i <= 232; i++) {
//     sum += i;
// }
// console.log("Sum of first 232 natural numbers is :", sum);
// console.log("Loop ended");

// let a = "Kushal";
// let b = a.replace("Kushal" , "Kushal Mahawar");
// console.log("Value of a is :", b);

// let c = (a + "\n").repeat(5);
// console.log("Value of c is :", c);


// let a = "hello";
// b = "";
// for (let i = 5; i >=0 ; i--) {
//     b += a[i]
// }
// // console.log(b);

// let marks = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
// console.log(marks.length);
// console.log(marks[0]);
// marks.push(110);
// console.log(marks);
// marks.pop();
// console.log(marks);
// console.log(marks.toString());
// console.log(marks.unshift(123));
// console.log(marks);
// console.log(marks.shift());
// console.log(marks);
// console.log(marks.slice(0 , 4));
// console.log(marks.splice(4 , 3  , 111 , 111 ,111));
// console.log(marks);
// console.log(marks.indexOf(111));



// let fruits = ["Bannana", "Apple", "Mango", "Orange"];
// fruits.sort().reverse();
// console.log(fruits);