//confirm("login to ws cube");
//console.log("hello world");
//document.write("hello world");
//prompt("hello" , "kushal");
// var name;
// name = "kushal";
// name = "Akshat";
// alert(name);

// const { default: OperatorNode } = require("three/src/nodes/math/OperatorNode.js")


// // -------This is used to get the text of id --------
// var x = document.getelementById("main").innerHTML;
// console.log(x);


// -------to change the data of id we write--------------
// document.getElementById("main").innerHTML = "<h1> Hey This Is kushal </h1>";



// ---Work through Class-------
// document.getElementsByClassName("main");

// var x = document.getElementsbyClassName("main")[0].innerHTML;
// alert(x);
// var x = document.getElementsbyClassName("main")[1].innerHTML;
// alert(x);

// document.getElementsByClassName("main")[0].innerHTML = "<h1> Hey This Is kushal </h1>";
// document.getElementsByClassName("main")[1].innerHTML = "<h1> Hey This Is Akshat </h1>";


//------Concatination of String-------
// var a = "kushal";
// var n = "akshat";
// var c = a + " " + n;
// console.log(c);
// var z = "hello" + " " + "world";
// console.log(z);

// ------Type of Operators in js ----------

// 1. Arthmatic Operator -    + , - , * , / , % , ++ , --
// 2. Logical Operator -   && , || , !
// 3. Ternary Operator - condition ? true : false
// 4. Assignment Operator - = , += , -= , *= , /= , %= , **=
// 5. Comparison Operator - == , === , != , !== , > , < , >= , <=
// 6. Bitwise Operator - & , | , ^ , ~ , << , >> , >>>

// ------Functions in js --------
// --Calling user defined function on click event--

// function greet() {
//     var name = document.getElementById('name').value;
//     var string = "Hello" + " " + name;
//     document.getElementsByClassName('greet')[0].innerHTML = string; 
    
// }

