// let a = 10;
// console.log(a);
// let b = 15;
// console.log(b);
// console.log(a + b);

setTimeout(() => {
    console.log("Kushal");
}, 2000);

// setTimeout ko execute karne ka kaam Browser karwata hai 

console.log("Helloo....");